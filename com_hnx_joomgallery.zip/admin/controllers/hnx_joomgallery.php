<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
 
// import Joomla controllerform library
jimport('joomla.application.component.controllerform');
 
/**
 * hnx_joomgallery Controller
 */
class hnx_joomgalleryControllerhnx_joomgallery extends JControllerForm
{
}